var myString = 'Learning about Built-in Objects is easy';
myString = myString.substring( 15, 31 );
myString = myString.toUpperCase();
document.body.innerHTML += "<h1>"" + myString + "</h1>";
