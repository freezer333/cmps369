var i = 12;
do {
 document.getElementById( "numbers" ).innerHTML += 
  "<li>" + i + " x 3 = " + (i * 3) +"</li>";
  i ++;
}
while (i < 11);
