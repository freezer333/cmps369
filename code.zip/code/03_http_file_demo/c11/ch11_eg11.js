$( document ).ready( function(){
  $( "#home" ).on( "click", function(){
    $( "#home" ).toggleClass( "selected" );
  });
  
});