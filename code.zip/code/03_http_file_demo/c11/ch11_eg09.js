$( document ).ready( function(){
  $( "#home" ).addClass( "selected" );
});