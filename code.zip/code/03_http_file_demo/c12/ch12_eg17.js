$( document ).ready( function(){
  $( "#dialog" ).dialog();  
});