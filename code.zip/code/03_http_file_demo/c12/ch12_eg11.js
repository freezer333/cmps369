$( document ).ready( function(){
  $( "#selectable" ).selectable();
});