$( document ).ready( function(){
  $( "#tabs" ).tabs();  
});