$( document ).ready( function(){
  $( "#datepicker" ).datepicker();  
});