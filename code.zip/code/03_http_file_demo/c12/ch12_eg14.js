$( document ).ready( function(){
  $( "#widgets" ).autocomplete({
    "source" : "data/ch12_eg14.json"
  });
});