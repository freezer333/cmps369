$( document ).ready( function(){
  $( "#menu" ).menu();  
});